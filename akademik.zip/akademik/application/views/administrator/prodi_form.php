<div class="container-fluid">
    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Form Tambah Program Studi
    </div>

    <form action="<?= base_url('administrator/prodi/tambah_prodi_aksi');?>" method="POST">
        <div class="form-group">
            <label for="kode_prodi">Kode Prodi</label>
            <input type="text" name="kode_prodi" class="form-control" placeholder="Masukan Kode prodi">
            <?= form_error('kode_prodi', '<div class="text-danger small ml-3">' , '</div>'); ?>
        </div>
        <div class="form-group">
            <label for="nama_prodi">Nama Prodi</label>
            <input type="text" name="nama_prodi" class="form-control" placeholder="Masukan nama prodi">
            <?= form_error('nama_prodi', '<div class="text-danger small ml-3">' , '</div>'); ?>
        </div>
        <div class="form-group">
            <label for="nama_jurusan">Nama Jurusan</label>
            <select name="nama_jurusan" id="nama_jurusan" class="form-control">
                <option value="" selected disabled > -->Pilih Jurusan<-- </option>
                <?php foreach($jurusan as $jrs):?>
                    <option value="<?= $jrs->nama_jurusan; ?>"><?= $jrs->nama_jurusan; ?></option>
                <?php endforeach;?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>

</div>