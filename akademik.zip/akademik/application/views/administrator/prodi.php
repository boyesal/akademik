<div class="container-fluid">
    <div class="alert alert-success" role="alert">
       <i class="fas fa-book-reader"></i> Program Study
    </div>

    <?= $this->session->flashdata('pesan'); ?>
    <?= anchor('administrator/prodi/input', '<button class="btn btn-sm btn-primary mb-3"><i class="fas fa-plus fa-sm"></i> TAMBAH PROGRAM STUDY </button>'); ?>

    <table class="table table-striped table-bordered table-hover">
        <tr>
            <th>No</th>
            <th>KODE PRODI</th>
            <th>NAMA PRODI</th>
            <th>NAMA JURUSAN</th>
            <th colspan="2">AKSI</th>
        </tr>

        <?php 
        $no = 1;
        foreach($prodi as $prd) : ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $prd->kode_prodi; ?></td>
                <td><?= $prd->nama_prodi; ?></td>
                <td><?= $prd->nama_jurusan; ?></td>
                <td width="20px">
                    <?= anchor('administrator/prodi/update/'. $prd->id , '<button class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></button>'); ?>
                </td>
                <td width="20px">
                    <?= anchor('administrator/prodi/delete/'. $prd->id , '<button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>'); ?>
                </td>
            </tr>
        <?php endforeach;?>
    </table>

</div>