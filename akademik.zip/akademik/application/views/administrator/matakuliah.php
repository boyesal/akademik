<div class="container-fluid">
    <div class="alert alert-success" role="alert">
       <i class="fas fa-book-reader"></i> Mata Kuliah
    </div>

    <?= $this->session->flashdata('pesan'); ?>
    <?= anchor('administrator/matakuliah/tambah_matakuliah', '<button class="btn btn-sm btn-primary mb-3"><i class="fas fa-plus fa-sm"></i> TAMBAH MATA KULIAH </button>'); ?>

    <table class="table table-striped table-bordered table-hover"  style="text-align:center;">
        <tr>
            <th>No</th>
            <th>KODE MATA KULIAH</th>
            <th>NAMA MATA KULIAH</th>
            <th>PROGRAM STUDI</th>
            <th colspan="3">AKSI</th>
        </tr>

        <?php 
        $no = 1;
        foreach($matakuliah as $mk) : ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $mk->kode_matakuliah; ?></td>
                <td><?= $mk->nama_matakuliah; ?></td>
                <td><?= $mk->nama_prodi; ?></td>
                <td width="20px">
                    <?= anchor('administrator/matakuliah/detail/'. $mk->kode_matakuliah , '<button class="btn btn-sm btn-success"><i class="fas fa-eye"></i></button>'); ?>
                </td>
                <td width="20px">
                    <?= anchor('administrator/matakuliah/update/'. $mk->kode_matakuliah , '<button class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></button>'); ?>
                </td>
                <td width="20px">
                    <?= anchor('administrator/matakuliah/delete/'. $mk->kode_matakuliah , '<button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>'); ?>
                </td>
            </tr>
        <?php endforeach;?>
    </table>


</div>