<div class="container-fluid">
    <div class="alert alert-success" role="alert">
       <i class="fas fa-book-reader"></i> Mahasiswa
    </div>

    <?= $this->session->flashdata('pesan'); ?>
    <?= anchor('administrator/mahasiswa/tambah_mahasiswa', '<button class="btn btn-sm btn-primary mb-3"><i class="fas fa-plus fa-sm"></i> TAMBAH MAHASISWA </button>'); ?>

    <table class="table table-striped table-hover table-bordered">
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>alamat</th>
                <th>Email</th>
                <th colspan="3">Aksi</th>
            </tr>
            <?php 
            $no = 1;
            foreach($mahasiswa as $mhs) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $mhs->nama_lengkap; ?></td>
                    <td><?= $mhs->alamat; ?></td>
                    <td><?= $mhs->email; ?></td>
                    <td width="20px">
                        <?= anchor('administrator/mahasiswa/detail/'. $mhs->id , '<button class="btn btn-sm btn-success"><i class="fas fa-eye"></i></button>'); ?>
                    </td>
                    <td width="20px">
                        <?= anchor('administrator/mahasiswa/update/'. $mhs->id , '<button class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></button>'); ?>
                    </td>
                    <td width="20px">
                        <?= anchor('administrator/mahasiswa/delete/'. $mhs->id , '<button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>'); ?>
                    </td>
                </tr>

            <?php endforeach; ?>
    </table>

</div>