<div class="container-fluid">
    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Jurusan
    </div>
    <?= $this->session->flashdata('pesan'); ?>
    <?= anchor('administrator/jurusan/input', '<button class="btn btn-sm btn-primary mb-3"><i class="fas fa-plus fa-sm"></i> TAMBAH JURUSAN</button>'); ?>
    
    <table class="table table-bordered table-striped table-hover">
        <tr>
            <th>No</th>
            <th>KODE JURUSAN</th>
            <th>NAMA JURUSAN</th>
            <th colspan="2">AKSI</th>
        </tr>
        <?php
        $no = 1;
        foreach ($jurusan as $jrs ) : ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $jrs->kode_jurusan; ?></td>
                <td><?= $jrs->nama_jurusan; ?></td>
                <td width="20px"><?= anchor('administrator/jurusan/update/'.$jrs->id_jurusan,'<div class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></div>'); ?></td>
                <td width="20px"><?= anchor('administrator/jurusan/delete/'.$jrs->id_jurusan,'<div class="btn btn-sm btn-primary"><i class="fas fa-trash"></i></div>'); ?></td>
                
            </tr>
        
        <?php endforeach; ?>
    </table>

</div>