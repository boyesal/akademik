<div class="container-fluid">
    <div class="alert alert-success" role="alert">
       <i class="fas fa-book-reader"></i> Tambah Mahasiswa
    </div>

    
    <form action="<?= base_url('administrator/mahasiswa/tambah_mahasiswa_aksi')?>" method="POST">
        <div class="row">
            <div class="col-md-6 md-4">
                <div class="form-group">
                    <label for="nim">NIM</label>
                    <input type="number" class="form-control" name="nim" value="<?= set_value('nim')?>">
                    <?= form_error('nim' ,'<div class="text-danger small">','</div>')?>
                </div>
                <div class="form-group">
                    <label for="Nama_lengkap">Nama lengkap</label>
                    <input type="text" class="form-control" name="Nama_lengkap" value="<?= set_value('nama_lengkap')?>">
                    <?= form_error('nama_lengkap' ,'<div class="text-danger small">','</div>')?>
                </div>
                <div class="form-group">
                    <label for="alamat">Alamat</label>
                    <input type="text" class="form-control" name="alamat" value="<?= set_value('alamat')?>">
                    <?= form_error('alamat' ,'<div class="text-danger small">','</div>')?>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" name="email" value="<?= set_value('email')?>">
                    <?= form_error('email' ,'<div class="text-danger small">','</div>')?>
                </div>
            </div>
            <div class="col-md-6 md-4">
                <div class="form-group">
                    <label for="telepon">Telepon</label>
                    <input type="number" class="form-control" name="telepon">
                </div>
                <div class="form-group">
                    <label for="tgl_lahir">Tanggal lahir</label>
                    <input type="date" class="form-control" name="tgl_lahir">
                </div>
                <div class="form-group">
                    <label for="jenis_kelamin">Jenis kelamin</label>
                    <input type="text" class="form-control" name="jenis_kelamin">
                </div>
                <div class="form-group">
                    <label for="nama_prodi">Program Studi</label>
                    <select name="nama_prodi" id="nama_prodi" class="form-control">
                        <option value=""></option>
                    </select>
                </div>
                <div class="form-group ">
                        <label for="photo">Photo</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="photo" name="photo">
                        <label class="custom-file-label" for="photo" aria-describedby="inputGroupFileAddon02">Choose file</label>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
        </div>
    </form>
</div>