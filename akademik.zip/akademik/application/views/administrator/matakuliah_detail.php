<div class="container-fluid">
    <div class="alert alert-success" role="alert">
       <i class="fas fa-eye"></i> Detail Mata Kuliah
    </div>

    <table class="table table-hover tabel-strtiped tabel-bordered">
        <?php foreach($detail as $dt) :?>
        <tr>
            <th>Kode Mata Kuliah</th>
            <td><?= $dt->kode_matakuliah; ?></td>
        </tr>
        <tr>
            <th>nama Mata Kuliah</th>
            <td><?= $dt->nama_matakuliah; ?></td>
        </tr>
        <tr>
            <th>SKS</th>
            <td><?= $dt->sks; ?></td>
        </tr>
        <tr>
            <th>semester</th>
            <td><?= $dt->semester; ?></td>
        </tr>
        <tr>
            <th>Nama Program Studi</th>
            <td><?= $dt->nama_prodi; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
        
    <?= anchor('administrator/matakuliah' , '<button class="btn btn-sm btn-primary" >Kembali</button>')?>

</div>