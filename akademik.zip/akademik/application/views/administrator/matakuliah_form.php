<div class="container-fluid">
     <div class="alert alert-success" role="alert">
       <i class="fas fa-book-reader"></i> Mata Kuliah
    </div>

<form action="<?= base_url('administrator/matakuliah/tambah_matakuliah_aksi')?>" method="POST">
    <div class="form-group">
        <label for="kode_matakuliah">Kode Mata Kuliah </label>
        <input type="text" name="kode_matakuliah" class="form-control">
        <?= form_error('kode_matakuliah', '<div class="text-danger small ml-3">','</div>'); ?>
    </div>
    <div class="form-group">
        <label for="nama_matakuliah">Nama Mata Kuliah </label>
        <input type="text" name="nama_matakuliah" class="form-control">
        <?= form_error('nama_matakuliah', '<div class="text-danger small ml-3">','</div>'); ?>
    </div>
    <div class="form-group">
        <label for="sks">SKS</label>
        <select name="sks" id="" class="form-control">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
        </select>
    </div>
    <div class="form-group">
        <label for="semester">Semester</label>
        <select name="semester" id="" class="form-control">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
        </select>
    </div>
    <div class="form-group">
        <label for="Program_studi">Program Studi</label>
        <select name="nama_prodi" id="" class="form-control">
            <option value="" selected disabled >-->Pilih Program Studi<--</option>
            <?php foreach($prodi as $prd) :?>
                <option value="<?= $prd->nama_prodi; ?>"><?= $prd->nama_prodi; ?></option>
            <?php endforeach;?>
        </select>
    </div>
    <button type="submit" class="btn btn-primary mb-5">Simpan</button>
</form>

</div>