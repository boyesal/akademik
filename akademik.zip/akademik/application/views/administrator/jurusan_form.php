<div class="container-fluid">

    <div class="alert alert-success" role="alert">
        <i class="fas fa-university"></i> Form Tambah Jurusan
    </div>

    <form action="<?= base_url('administrator/jurusan/input_aksi');?>" method="POST">
        <div class="form-group">
            <label for="kode_jurusan">Kode Jurusan</label>
            <input type="text" name="kode_jurusan" class="form-control" placeholder="Masukan Kode Jurusan">
            <?= form_error('kode_jurusan', '<div class="text-danger small ml-3">' , '</div>'); ?>
        </div>
        <div class="form-group">
            <label for="nama_jurusan">Nama Jurusan</label>
            <input type="text" name="nama_jurusan" class="form-control" placeholder="Masukan nama Jurusan">
            <?= form_error('nama_jurusan', '<div class="text-danger small ml-3">' , '</div>'); ?>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>