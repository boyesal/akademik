<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class mahasiswa_model extends CI_Model {

    public function tampil_data($tabel)
    {
        return $this->db->get($tabel);
    }

    public function insert_data($tabel, $data)
    {
        $this->db->insert('mahasiswa');
    }

    

}

/* End of file mahasiswa_model.php */
