<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class prodi_model extends CI_Model {

    public function tampil_data()
    {
        return $this->db->get('prodi');
    }

    public function insert_data($data)
    {
        return $this->db->insert('prodi', $data);
    }

    public function tampil_data_jurusan()
    {
        return $this->db->get('jurusan');
    }

    public function update_data($where,$data)
    {
        $this->db->where($where);
        $this->db->update('prodi',$data);
    }

    public function hapus_data($where)
    {
        $this->db->where($where);
        $this->db->delete('prodi');
    }

}

/* End of file prodi_odel.php */
