<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class matakuliah_model extends CI_Model {

    public function tampil_data($tabel)
    {
        return $this->db->get($tabel);
    }

    public function insert_data($data, $tabel) 
    {
        $this->db->insert($tabel,$data);
    }

    public function ambil_kode_matakuliah($kode)
    {
        $result = $this->db->where('kode_matakuliah', $kode)->get('matakuliah');
        if($result->num_rows() > 0) {
            return $result->result();
        } else {
            return false;
        }
    }

    public function update_data($where, $data, $tabel) 
    {
        $this->db->where($where);
        $this->db->update($tabel,$data);
    }

}

/* End of file matakuliah_model.php */
