<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class jurusan_model extends CI_Model {

    public function tampil_data()
    {
        return $this->db->get('jurusan');
    }

    public function input_data($data)
    {
        return $this->db->insert('jurusan',$data);
    }

    public function edit_data($where)
    {
        return $this->db->get_where('jurusan',$where);
    }

    public function update_data($where, $data)
    {
        $this->db->where($where);
        $this->db->update('jurusan',$data);
    }

    public function hapus_data($where)
    {
        $this->db->where($where);
        $this->db->delete('jurusan');
    }

}

/* End of file jurusan_model.php */
