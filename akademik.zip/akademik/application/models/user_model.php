<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class user_model extends CI_Model 
{

    public function ambil_data($id)
    {
        $this->db->where('username', $id);
        return $this->db->get('user')->row();
    }
    

}

/* End of file user_model.php */
